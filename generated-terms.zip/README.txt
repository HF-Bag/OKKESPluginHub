﻿共享扫描词库：6,204 对繁简对应词条。
解压得到 generated-terms.json。v1.1 已内置同样的基础词库，没有双客户端也能直接使用。
如需更新自动层：退出 ok-kes 和插件中心；备份插件当前数据目录下 data/generated-terms.json，再用本文件替换。保留自己的 data/terms.json，人工校正仍优先。
词库管理中的“导入…”会作为人工优先层导入，并非自动层更新。详细说明：https://github.com/TYH-great/OKKESPluginHub
本插件由AI制作，完全免费分享。使用自愿，请备份并自行核对词条；免责声明见仓库。